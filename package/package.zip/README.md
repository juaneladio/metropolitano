Metropolitano
=============

Una aplicación para Firefox OS (y cualquier navegador web) para usuarios del Metropolitano, un sistema de transporte público en Lima, Perú.

Esta aplicación fue construida usando Firefox OS Building Blocks
http://buildingfirefoxos.com/
