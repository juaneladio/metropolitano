### Which branch?
- Critical bugs are fixed in the master branch.
- Normal bugs are fixed in the develop branch.
- New features are added to the develop branch, too.

### Code style
- Please use 4 soft spaces per indent level.
- Take a look at the coding style used in codebird.js and apply the same convention to your contributed code.

### License
- Code contributed by you will get the same license as Codebird itself, that is, GPU General Public License V3.
